<div class="cleared"></div><div class="art-Footer">
                    <div class="art-Footer-inner">
                        <a href="#" class="art-rss-tag-icon" title="RSS"></a>
                        <div class="art-Footer-text">
                            <p><a href="contact.php">Contact Us</a> | <a href="terms.php">Terms of Use</a> 
                                | <a href="prvs.php">Privacy Statement</a> | <a href="isuser.php">Online User</a><br />
                                Copyright &copy; 2012 ---. All Rights Reserved.</p>
                        </div>
                    </div>
                    <div class="art-Footer-background"></div>
                </div>
            </div>
        </div>
           
</body>



</html>